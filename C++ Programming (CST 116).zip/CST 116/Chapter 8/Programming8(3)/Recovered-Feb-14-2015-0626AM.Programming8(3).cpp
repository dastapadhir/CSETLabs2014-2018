#include<iostream>
using std::cout;
using std::cin;
using std::endl;
int main()
{
	int ch = 0;
	int c1 = 0;
	cout << "Press 1. Area" << endl;
	cout << "Press 2. Volume" << endl;
	cin >> ch;
	switch (ch)
	{
	case 1:
		cout << "ress a.Rectangle " << endl;
			cout << 