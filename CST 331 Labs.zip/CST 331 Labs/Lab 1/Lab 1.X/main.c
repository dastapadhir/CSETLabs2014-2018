#pragma config POSCMOD=XT, FNOSC=PRIPLL, FPLLIDIV=DIV_2, FPLLMUL=MUL_20
#pragma config FPLLODIV=DIV_1
#pragma config FPBDIV=DIV_1, FWDTEN=OFF, CP=OFF, BWP=OFF
#pragma config FSOSCEN=OFF, IESO=OFF
#include <xc.h>
#define _SUPPRESS_PLIB_WARNING
#include<plib.h>

#define maximum 8192 //Max capacity in buffer

//#pragma interrupt InterruptServiceRoutine IPL6AUTO vector 24 //Interrupts
#pragma interrupt Timer23ISR IPL6AUTO vector 12
//#pragma interrupt Timer45ISR IPL5AUTO vector 20 
#pragma interrupt DMAReceive IPL6AUTO vector 38
#pragma interrupt DMATransmit IPL6AUTO vector 39

//#pragma interrupt Timer2 IPL5AUTO vector 8

void DMAReceive(void); //DMA Receive Channel 2 interrupt
void DMATransmit(void); //DMA Receive Channel 3 interrupt
void Timer23ISR(void); //Turn off LED
void debounce(int chk);
//void Timer45ISR(void); //Receive
//void Timer2(void);

char Buffer[maximum]={'T'};

int buffercounter=0;

char * Head = Buffer; // points to where next item is to be placed if the buffer is not full
char * Tail = Buffer; //points to where next item can be removed if the buffer is not empty
char * Top = &Buffer[0]; //points to the beginning of the buffer in memory
char * End = &Buffer[maximum]; //points to the end of the buffer in memory
int num_items = 0; //number of items in the buffer
int DisableAtNextTx = 0;        //flag is activated once buffer is empty 
                                //and transmission can stop
int overflow=0;
int transmitcounter=0, excess = 0;

void Insert(char);
char Remove();
int LEDVALUE=0x0001;
short TIMERVALUE=0x8000;
int last_transfer=0;
int receiveElements=0;

int main()
{
    int counter=0;
    int i=0;
    
    SYSTEMConfig(80000000L,SYS_CFG_WAIT_STATES|SYS_CFG_PCACHE); 
        
    OpenTimer1(T1_OFF | T1_SOURCE_INT | T1_PS_1_1, 1200); //Debounce Button AKA CHANGE NOTIFICATION
    mT1SetIntPriority(5); //Sets the IPL in Hardware for CHANGE NOTIFICATION
    mT1SetIntSubPriority(1); //Sets the Sub Priority
   
    OpenTimer23(T23_OFF | T23_SOURCE_INT | T23_PS_1_256, 156250); //Transmit 
    mT23SetIntPriority(6); //Sets the IPL in Hardware for Timer 2 and 3
    mT23SetIntSubPriority(2); //Sets the Sub Priority
    mT23IntEnable(1);
    
    OpenTimer45(T45_OFF | T45_SOURCE_INT | T45_PS_1_256, 156250); //Receive
    mT45SetIntPriority(5);
    mT45SetIntSubPriority(3);
    mT45IntEnable(1);
    
    
    //DMA SETUP
    mDMA2SetIntPriority(6); //Receive
    mDMA2IntEnable(1);
    mDMA3SetIntPriority(6); //Transmit
    mDMA3IntEnable(1);
    mDMA1SetIntPriority(6); //Turning on the LED
    mDMA1IntEnable(1);
    mDMA0SetIntPriority(6); //Turning off LED
    mDMA0SetIntPriority(1);
            
    IEC1bits.DMA3IE=1; //Enabling DMA channel 3 (Transmit)
    IEC1bits.DMA2IE=1; //Enabling DMA Channel 2 (Receive)
    IEC1bits.DMA1IE=1;//Enabling Channel 1
    IEC1bits.DMA0IE=1; //Enabling Channel 0
  
    DCH2INTCLR=0x00FF00FF; // DMA2: clear events, disable interrupts
    DCH3INTCLR=0x00FF00FF; // DMA3: clear events, disable interrupts
    DCH1INTCLR=0x00FF00FF; // DMA1: clear events, disable interrupts
    DCH0INTCLR=0x00FF00FF; // DMA0: clear events, disable interrupts
    
    DCH2INTSET=0x00080000; // DMA 2: enable Block Complete and error interrupts
    DCH3INTSET=0x00080000; // DMA 3: enable Block Complete and error interrupts
    
   
    DCH2CONbits.CHPRI=3; //Receive gets highest priority
    DCH3CONbits.CHPRI=2; //Transmit gets lowest priority
    DCH1CONbits.CHPRI=1;  //Turning on the LED
    DCH0CONbits.CHPRI=0;  //Turning off the LED
    
    DCH2ECONbits.CHSIRQ = 27; //DMA Channel 2 will be controlled by Receive
    DCH2ECONbits.SIRQEN = 1; //Turn on
    
    DCH3ECONbits.CHSIRQ = 28; //DMA Channel 3 will be controlled by transmit
    DCH3ECONbits.SIRQEN = 1; //Turn on
    
    DCH1ECONbits.CHSIRQ = 27; //DMA Channel 1 will turn on the LED
    DCH1ECONbits.SIRQEN = 1; //Turn on
    
    DCH0ECONbits.CHSIRQ = 27; //DMA Channel 0 will be reset the timer
    DCH0ECONbits.SIRQEN = 1; //Turn on
    
  
    DCH2CONbits.CHAED=1; //Receive AED
    DCH2CONbits.CHAEN=1;  //Receive Auto Enable
    
    DCH3CONbits.CHAED=1; //Transmit
    DCH3CONbits.CHAEN=1;
    
    DCH1CONbits.CHAED=1; //Turning on LED
    DCH1CONbits.CHAEN=1;
    
    DCH0CONbits.CHAED=1; //Turning off LED
    DCH0CONbits.CHAEN=1;
    
    DCH2SSA=KVA_TO_PA(&U1RXREG); //Receive source address
    DCH2DSA=KVA_TO_PA(&Buffer); //Receive destination address
    
    DCH3SSA=KVA_TO_PA(&Buffer); // Transmit source address
    DCH3DSA=KVA_TO_PA(&U1TXREG); //Transmit destination address
    
    DCH2SSIZ=1; //Channel 2 Source 1 byte
    DCH2DSIZ=0; //Channel 2 Destination 256 bytes
    DCH2CSIZ=1; //Channel 2 Cell 1 byte
    
    DCH3SSIZ=0; //Channel 3 Source 256 bytes
    DCH3DSIZ=1; //Channel 3 Destination 1 byte
    DCH3CSIZ=1; //Channel 3 Cell 1 byte
    
    DCH1SSA=KVA_TO_PA(&LEDVALUE); //Receive source address
    DCH1DSA=KVA_TO_PA(&PORTDSET); //Receive destination address
    
    DCH1SSIZ=2; //Channel 1 Source 2 bytes
    DCH1DSIZ=2; //Channel 1 Destination 2 bytes
    DCH1CSIZ=2; //Channel 1 Cell 2 bytes
    
    DCH0SSA=KVA_TO_PA(&TIMERVALUE); //Receive source address
    DCH0DSA=KVA_TO_PA(&T2CONSET); //Receive destination address

    DCH0SSIZ=2; //Channel 0 Source 2 bytes
    DCH0DSIZ=2; //Channel 0 Destination 2 bytes
    DCH0CSIZ=2; //Channel 0 Cell 2 bytes
    
    DMACONbits.ON=1; //Turns on the DMA 
    
    DCH2CONbits.CHEN=1; //Enable DMA Receive  
    DCH3CONbits.CHEN=1; //Enable DMA Transmit
    DCH1CONbits.CHEN=1;  //Turning on the LED
    DCH0CONbits.CHEN=1; //Resetting the timer
    
    
    
    U1MODEbits.RTSMD=0; //Setting Flow Control
    U1MODEbits.UEN=0b10; //U2TX, U2RX, U2CTS, and U2RTS pins are enabled and used
    
    //PORT
    TRISFbits.TRISF3=0;// Set as output
    LATFbits.LATF3=1; // Output high (idle)
    
   //Receive LED
    TRISDbits.TRISD0=0; //Configuring PORTB10 as an output TRISD
    LATDbits.LATD0=0; //Setting the LATB B10 PORTD
    
    
    //Transmit LED
    TRISDbits.TRISD1=0; //Configuring PORTB10 as an output TRISD
    LATDbits.LATD1=0; //Setting the LATB B10 PORTD
    
    
    //Overflow LED
    TRISDbits.TRISD2=0; //Configuring PORTB10 as an output TRISD
    LATDbits.LATD2=0; //Setting the LATB B10 PORTD
    
    //Button RD13 
    TRISCbits.TRISC2=1; //Setting up as input
    LATCbits.LATC2=1; //Setting up LATC RC1 as
    
    U1BRG=173; //That gives a baud rate of 114.9 K which gives the least error
    U1MODEbits.BRGH=1; //BRGH is 4 
    
    U1MODEbits.PDSEL=00; //8 bits, no parity
    U1MODEbits.STSEL=0; //1 stop bit
            
    
    mU1SetIntPriority(6);
    mU1SetIntSubPriority(1);
    
    INTEnableSystemMultiVectoredInt();//Setting up the multi vectored mode
    
    U1STAbits.UTXISEL=0b01; //when buffer and txsr are both empty
    U1STAbits.URXISEL=0b00; //When character is received
    
    U1MODEbits.ON=1; //Turning the UART on
     
    U1STAbits.URXEN=1; //Setting the receiver on 
    while(1){
        debounce(0);
    
                LATDbits.LATD1=0; //Setting the LATB B10 PORTD
                excess = DCH2DPTR; //read DMA Ch 2 (recieve) DPTR to manage less than full buffer
                if(buffercounter < 1) 
                {
                    if(excess==0)
                    {
                        U1STAbits.UTXEN=0;
                        continue;
                    }
                    DCH3SSIZ = excess;
                } 
                else 
                {
                    DCH3SSIZ = 0;
                }
                buffercounter--;
                U1STAbits.UTXEN = 1; //Starting the DMA
               
        debounce(1);
    }                       
    return 0;
}

void debounce(int chk) {
    int i, counter = 0;
    
    while(1)
    { 

        if((PORTCbits.RC2 == chk))
        {
            for(i=0; i < 3; i++)
            {
              TMR1=0; //Clearing the Timer
              T1CONbits.TON=1; //Start the Timer
              while(TMR1!=1200); //15 ms time delay
              T1CONbits.TON=0; //Turn off timer
                if(PORTCbits.RC2 == chk)
                {   
                    counter++;
                    IFS0CLR=0x00000010;
                }
            }
            if(counter==3)
            {
                return;
            }
            counter=0;  
            T1CONbits.TON=0; //Stop Timer 
            TMR1=0; //Clear Timer
        }

    }
} 

   
void DMAReceive(void)
{
   
    DCH2INTCLR=0x00000008; // DMA2: enable Block Complete and error interrupts and stopwatch end
    IFS1bits.DMA2IF=0; //Clear DMA Channel 2 Interrupt Flag  (Receive)
    receiveElements=(buffercounter*256) + excess;
    
    if(buffercounter < 31)
    {
        DCH2DSA = DCH2DSA+256;
        buffercounter++; //Stopwatch Start
    }
    else 
    {
        PORTDbits.RD2=1;
        overflow=1;
    }
}

void DMATransmit(void)
{
    DCH3INTCLR=0x00000008; // DMA2: enable Block Complete and error interrupts
    IFS1bits.DMA3IF=0; //Clear DMA Channel 2 Interrupt Flag  (Receive)
   
    //receiveElements=(buffercounter*256)+excess;    
    if(overflow==1)
    {
        PORTDbits.RD2=0; //Turn off the LED
        overflow=0;
    }
    if(transmitcounter < buffercounter)
    {
        DCH3SSA=DCH3SSA+256;
        transmitcounter++;
    }
    else if(transmitcounter == buffercounter && excess > 0)
    {
            DCH3SSIZ = excess;
            DCH3SSA=DCH3SSA + 256; // Added
            transmitcounter++;
    }
    else
    {
       transmitcounter=0;
       buffercounter=0;
       DCH2DSA=KVA_TO_PA(&Buffer); //Receive destination address
       DCH3SSA=KVA_TO_PA(&Buffer); // Transmit source address
       DCH3CONbits.CHEN=1; //Enable DMA Transmit  
       DCH2CONbits.CHEN=1; //Enable DMA Receive  
       //memset(&Buffer, 0x00, maximum);
       while(U1STAbits.TRMT == 0);
       U1STAbits.UTXEN=0;
    } 
}

void Timer23ISR(void)
{
    T2CONbits.TON=0; //Turn off the timer
    LATDbits.LATD0=0; //Turn off the LED
    TMR2=0; //Clear the Timer 
    IFS0CLR= 0x00001100; //Clear the T2 Interrupt Flag
}

