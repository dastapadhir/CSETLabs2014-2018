#include<xc.h>
// Global Defines
#pragma config FPLLIDIV = DIV_1         // System PLL Input Divider (1x Divider)
#pragma config FPLLRNG = RANGE_8_16_MHZ // System PLL Input Range (8-16 MHz Input)
#pragma config FPLLICLK = PLL_POSC      // System PLL Input Clock Selection (POSC is input to the System PLL)
#pragma config FPLLMULT = MUL_32        // System PLL Multiplier (Need 350MHz < FVco < 700 MHz) 12 * 32
#pragma config FPLLODIV = DIV_4         // System PLL Output Clock Divider (2x Divider) 12MHz / 1 * 32 / 4 = 96MHz
#pragma config UPLLFSEL = FREQ_12MHZ    // USB PLL Input Frequency Selection (USB PLL input is 12 MHz)
#pragma config UPLLEN = OFF             // USB PLL Enable (USB PLL is disabled)

// DEVCFG1
#pragma config FNOSC = SPLL             // Oscillator Selection Bits (Primary Osc (HS,EC))
#pragma config FSOSCEN = OFF            // Secondary Oscillator Enable (Disable SOSC)
#pragma config POSCMOD = HS             // Primary Oscillator Configuration (HS osc mode)
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor Selection (Clock Switch Disabled, FSCM Disabled)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (WDT Disabled)
#pragma config FDMTEN = OFF             // Deadman Timer Enable (Deadman Timer is disabled)
#pragma config DMTINTV = WIN_127_128    // Default DMT Count Window Interval (Window/Interval value is 127/128 counter value)

// DEVCFG0
#pragma config JTAGEN = OFF             // JTAG Enable (JTAG Disabled)
#pragma config ICESEL = ICS_PGx2        // ICE/ICD Comm Channel Select (Communicate on PGEC2/PGED2)
#define PORT0_CS3 0xE0012000
#define PORT1_CS3 0xE0014000
#define RAM_SIZE 2*1024*1024
#define MEM_SIZE 0x2000 //Size of the memory buffer or 16K

unsigned char * read;
unsigned char * write;
unsigned char * testvalue = 0xAA; 
unsigned char * value;

unsigned char * zerocheck;
unsigned char * onecheck;
unsigned char * sevencheck;

int zeroint;
int oneint;
int sevenint;


int main()
{
    int i =0; 
    int j =0; 
 //Setting up the LED
 TRISHbits.TRISH2=0; //Configuring PORTB10 as an output TRISD
 LATHbits.LATH2=0; //Setting the LATB B10 PORTD
    
 ANSELACLR = 0x10; //EBI Pin A5
 TRISACLR = 0x10;
 
 ANSELBCLR = 0x300; //EBI Pin A7 and A10
 TRISBCLR = 0x300;
 
 ANSELCCLR = 0x1E; //EBI Pin A6, A12, OE, WE
 TRISCCLR = 0x1E;
 
 ANSELECLR = 0x00F0; //EBI Pin D4,D5,D6,D7
 TRISECLR = 0x00F0;
 
 ANSELGCLR = 0x200; //EBI Pin A2
 TRISGCLR = 0x200;
 
 // Note: ISSI SRAM (IS64WV102416BLL). All of the parameters of the EBI
 // module are set up based on the timing of this RAM.
 // Enable address lines [0:17]
 // Controls access of pins shared with PMP
 CFGEBIA = 0x800FFFFF;

 //Enable write enable pin
 //Enable output enable pin
 //Enable byte select pin 0
 //Enable byte select pin 1
 //Enable Chip Select 0
 //Enable data pins [0:15]
 CFGEBIC = 0x00003393;
 //Connect CS0 to physical address
 EBICS3 = 0x20014000;
 //EBICS0 =  0x20000000;
 // Memory size is set as 2 MB
 // Memory type is set as SRAM
 // Uses timing numbers in EBISMT0
 
 //EBIMSK0 = 0x00000026;
 
 EBIMSK3bits.MEMTYPE =0b001; // Device Type: SRAM
 EBIMSK3bits.MEMSIZE = 0b00001; //64K device
 EBIMSK3bits.REGSEL = 0b010; //Device timing use EBISMT2
 
 // Configure EBISMT0 
 // ISSI device has read cycles time of 10 ns
 // ISSI device has address setup time of 0ns
 // ISSI device has address/data hold time of 2.5 ns
 // ISSI device has Write Cycle Time of 10 ns
 // Bus turnaround time is 0 ns
 // No page mode
 // No page size
 // No RDY pin
 
 
 EBISMT2bits.RDYMODE=0; //Turn off the Ready Mode
 EBISMT2bits.PAGEMODE= 0; //Page Mode Off
 EBISMT2bits.TRC=0x4; // Read Cycle 82.8 ns ~ 83 ns (Total write cycles +1 =8 )
 EBISMT2bits.TAS=0x1; //10.4 ns for Address Setup
 EBISMT2bits.TWR=0x1; //10.4 ns for Address Hold
 EBISMT2bits.TWP= 0x2; // Write Cycle 82.8 ns ~ 83 ns (Total write cycles +1 =8 )
 EBISMT2bits.TBTA=1; //Bus turn around time is 0 ns
 
 //Keep default data width to 16-bits
 
 EBISMCON = 0x00009200; //Change to 8 bits
 
//read = (unsigned char * )SRAM_ADDR_CS3; //Pointing to the base of the address space
write = (unsigned char * )PORT0_CS3; //Pointing to the base of the address space

*write = 0xA5;
for(i =0; i < 250000 ; i++)
{
    
}
write = (unsigned char * )PORT1_CS3; //Pointing to the base of the address space
*write = 0xF0;

 while(1);
}