#include<xc.h>
// Global Defines
#pragma config FPLLIDIV = DIV_1         // System PLL Input Divider (1x Divider)
#pragma config FPLLRNG = RANGE_8_16_MHZ // System PLL Input Range (8-16 MHz Input)
#pragma config FPLLICLK = PLL_POSC      // System PLL Input Clock Selection (POSC is input to the System PLL)
#pragma config FPLLMULT = MUL_32        // System PLL Multiplier (Need 350MHz < FVco < 700 MHz) 12 * 32
#pragma config FPLLODIV = DIV_4         // System PLL Output Clock Divider (2x Divider) 12MHz / 1 * 32 / 4 = 96MHz
#pragma config UPLLFSEL = FREQ_12MHZ    // USB PLL Input Frequency Selection (USB PLL input is 12 MHz)
#pragma config UPLLEN = OFF             // USB PLL Enable (USB PLL is disabled)

// DEVCFG1
#pragma config FNOSC = SPLL             // Oscillator Selection Bits (Primary Osc (HS,EC))
#pragma config FSOSCEN = OFF            // Secondary Oscillator Enable (Disable SOSC)
#pragma config POSCMOD = HS             // Primary Oscillator Configuration (HS osc mode)
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor Selection (Clock Switch Disabled, FSCM Disabled)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (WDT Disabled)
#pragma config FDMTEN = OFF             // Deadman Timer Enable (Deadman Timer is disabled)
#pragma config DMTINTV = WIN_127_128    // Default DMT Count Window Interval (Window/Interval value is 127/128 counter value)

// DEVCFG0
#pragma config JTAGEN = OFF             // JTAG Enable (JTAG Disabled)
#pragma config ICESEL = ICS_PGx2        // ICE/ICD Comm Channel Select (Communicate on PGEC2/PGED2)
#define SRAM_ADDR_CS0 0xE0000000
#define RAM_SIZE 2*1024*1024
#define MEM_SIZE 0x2000 //Size of the memory buffer or 16K

 unsigned char * buffer;
 unsigned char * value1 ;
 unsigned char * value2 ;
 unsigned char * value3;
 unsigned char * value4 ;
 
 //unsigned char * VALUE= 0xFF;
// unsigned char * VALUE = 0x00;
// unsigned char * VALUE = 0x55;
// unsigned char * VALUE = 0xAA;
 
 //char * CHECK = 0x0F; 
// char * CHECK =  0x0A;
// char * CHECK = 0x05;
// char * CHECK = 0x00;
 
 unsigned int maskcheck;
 unsigned int testmask;
unsigned short * writebuffer;// Ability to hold data betweeen 0x0000 and 0x1FFF
unsigned short startvalue;
unsigned int * readbuffer; 
unsigned int temp;
 
int main(void)
{
 int loop=0;
 int i=0;
// value1 = 0x00;
// value2 = 0xFF;
// value3 = 0xAA;
// value4 = 0x55;
 unsigned int val;
 
 startvalue =0x0000;
 
 //Setting up the LED
 TRISHbits.TRISH2=0; //Configuring PORTB10 as an output TRISD
 LATHbits.LATH2=0; //Setting the LATB B10 PORTD
    
 ANSELACLR=0x10; //EBI Pin A5
 TRISACLR=0x10;
 
 ANSELBCLR=0x300; //EBI Pin A7 and A10
 TRISBCLR= 0x300;
 
 ANSELCCLR=0x1E; //EBI Pin A6, A12, OE, WE
 TRISCCLR= 0x1E;
 
 ANSELECLR = 0x00F0; //EBI Pin D4,D5,D6,D7
 TRISECLR = 0x00F0;
 
 ANSELGCLR = 0x200; //EBI Pin A2
 TRISGCLR = 0x200;
 
 // Note: ISSI SRAM (IS64WV102416BLL). All of the parameters of the EBI
 // module are set up based on the timing of this RAM.
 // Enable address lines [0:17]
 //Controls access of pins shared with PMP
 CFGEBIA = 0x800FFFFF;

 //Enable write enable pin
 //Enable output enable pin
 //Enable byte select pin 0
 //Enable byte select pin 1
 //Enable Chip Select 0
 //Enable data pins [0:15]
 CFGEBIC = 0x00003313;
 //Connect CS0 to physical address
 EBICS0 = 0x20000000;
 // Memory size is set as 2 MB
 // Memory type is set as SRAM
 // Uses timing numbers in EBISMT0
 
 //EBIMSK0 = 0x00000026;
 
 EBIMSK0bits.MEMTYPE=0b001; // Device Type: SRAM
 EBIMSK0bits.MEMSIZE = 0b00001; //64K device
 EBIMSK0bits.REGSEL= 0b000; //Device timing use EBISMT0
 
 
 
 //Configure EBISMT0
 // ISSI device has read cycles time of 10 ns
 // ISSI device has address setup time of 0ns
 // ISSI device has address/data hold time of 2.5 ns
 // ISSI device has Write Cycle Time of 10 ns
 // Bus turnaround time is 0 ns
 // No page mode
 // No page size
 // No RDY pin
 
 //EBISMT0 = 0x000029CA;
 
 EBISMT0bits.RDYMODE=0; //Turn off the Ready Mode
 EBISMT0bits.PAGEMODE= 0; //Page Mode Off
 EBISMT0bits.TRC=0x4; // Read Cycle 82.8 ns ~ 83 ns (Total write cycles +1 =8 )
 EBISMT0bits.TAS=0x1; //10.4 ns for Address Setup
 EBISMT0bits.TWR=0x1; //10.4 ns for Address Hold
 EBISMT0bits.TWP= 0x2; // Write Cycle 82.8 ns ~ 83 ns (Total write cycles +1 =8 )
 EBISMT0bits.TBTA=1; //Bus turn around time is 0 ns
 
 //Keep default data width to 16-bits
 
 EBISMCON = 0x00000000;
 
 writebuffer = (unsigned short * )SRAM_ADDR_CS0; //Pointing to the base of the address space
 
 //Write loop

 
 while(startvalue < MEM_SIZE)
 { 
        *writebuffer++ = startvalue; //Write value into the address space
        startvalue++;  //Increment value
 }
 
 
 //Read and verify loop

 readbuffer = (unsigned int *)SRAM_ADDR_CS0; //Pointing at the base of the address space
 maskcheck = 0x00010000; //Value to compare masked value against
 for (startvalue=0 ; startvalue < MEM_SIZE; startvalue=startvalue +2 )
 {   
    temp = *readbuffer++; 
    temp = temp & 0xFF0FFF0F; //Masked value so both D4-D7 bits are accounted for
    testmask = maskcheck & 0xFF0FFF0F; //mask the test value so they stay the same as the read in value that gets masked.
    if(temp != testmask) 
    {
            LATHbits.LATH2=1;
    }
    maskcheck = maskcheck + 0x00020002; //Increment the mask value as there are two 16 bit values in a 32 bit
    LATHbits.LATH2=0;
 }
  while(1);

} 