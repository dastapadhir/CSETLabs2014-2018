//#include<xc.h>
////#include<plib.h>
//// Global Defines
//#pragma config FPLLIDIV = DIV_1         // System PLL Input Divider (1x Divider)
//#pragma config FPLLRNG = RANGE_8_16_MHZ // System PLL Input Range (8-16 MHz Input)
//#pragma config FPLLICLK = PLL_POSC      // System PLL Input Clock Selection (POSC is input to the System PLL)
//#pragma config FPLLMULT = MUL_32        // System PLL Multiplier (Need 350MHz < FVco < 700 MHz) 12 * 32
//#pragma config FPLLODIV = DIV_4         // System PLL Output Clock Divider (2x Divider) 12MHz / 1 * 32 / 4 = 96MHz
//#pragma config UPLLFSEL = FREQ_12MHZ    // USB PLL Input Frequency Selection (USB PLL input is 12 MHz)
//#pragma config UPLLEN = OFF             // USB PLL Enable (USB PLL is disabled)
//
//// DEVCFG1
//#pragma config FNOSC = SPLL             // Oscillator Selection Bits (Primary Osc (HS,EC))
//#pragma config FSOSCEN = OFF            // Secondary Oscillator Enable (Disable SOSC)
//#pragma config POSCMOD = HS             // Primary Oscillator Configuration (HS osc mode)
//#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor Selection (Clock Switch Disabled, FSCM Disabled)
//#pragma config FWDTEN = OFF             // Watchdog Timer Enable (WDT Disabled)
//#pragma config FDMTEN = OFF             // Deadman Timer Enable (Deadman Timer is disabled)
//#pragma config DMTINTV = WIN_127_128    // Default DMT Count Window Interval (Window/Interval value is 127/128 counter value)
//
//// DEVCFG0
//#pragma config JTAGEN = OFF             // JTAG Enable (JTAG Disabled)
//#pragma config ICESEL = ICS_PGx2        // ICE/ICD Comm Channel Select (Communicate on PGEC2/PGED2)
//#define SRAM_ADDR_CS0 0xE0000000
//#define RAM_SIZE 2*1024*1024
//
//
//
//int main(void)
//{
// unsigned int loop;
// unsigned int *addr;
// unsigned int val;
// // Note: ISSI SRAM (IS64WV102416BLL). All of the parameters of the EBI
//// module are set up based on the timing of this RAM.
// // Enable address lines [0:17]
// //Controls access of pins shared with PMP
// CFGEBIA = 0x800FFFFF;
//
// //Enable write enable pin
// //Enable output enable pin
// //Enable byte select pin 0
// //Enable byte select pin 1
// //Enable Chip Select 0
// //Enable data pins [0:15]
// CFGEBIC = 0x00003313;
// //Connect CS0 to physical address
// EBICS0 = 0x20000000;
// EBICS2 = 0x20110000;
// // Memory size is set as 2 MB
// // Memory type is set as SRAM
// // Uses timing numbers in EBISMT0
// EBIMSK0 = 0x00000026;
// EBIMSK2bits.MEMSIZE = 0b00101;
// EBIMSK2bits.REGSEL = 0b000;
// EBIMSK2bits.MEMTYPE = 0b010; /* Device 3: NOR Flash */
// //Configure EBISMT0
// // ISSI device has read cycles time of 10 ns
// // ISSI device has address setup time of 0ns
// // ISSI device has address/data hold time of 2.5 ns
// // ISSI device has Write Cycle Time of 10 ns
// // Bus turnaround time is 0 ns
// // No page mode
// // No page size
// // No RDY pin
// EBISMT0 = 0x00002FCA;
// //Keep default data width to 16-bits
// EBISMCON = 0x00000000;
// 
// addr = (unsigned int *)SRAM_ADDR_CS0;
// //Write loop
// //*addr++ = 0xAA55AA55;
// for (loop=0; loop < RAM_SIZE/4; loop++)
// {
//    *addr++ = 0xAA55AA55;
// }
// //Read and verify loop
//
//addr = (unsigned int *)SRAM_ADDR_CS0; // reset address to beginning
//val = *addr++;
// for (loop=0 ; loop < RAM_SIZE/4; loop++)
// {
//   val = *addr++;
//   if (val != 0xAA55AA55)
//   {
//     return (0); //Exit Failure
//   }
// }
//
// return (1); // exit success
//} 
