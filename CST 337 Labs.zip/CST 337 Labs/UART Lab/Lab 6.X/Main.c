
#pragma config POSCMOD=XT, FNOSC=PRIPLL, FPLLIDIV=DIV_2, FPLLMUL=MUL_20
#pragma config FPLLODIV=DIV_1
#pragma config FPBDIV=DIV_1, FWDTEN=OFF, CP=OFF, BWP=OFF
#pragma config FSOSCEN=OFF, IESO=OFF
#include <xc.h>
#define _SUPPRESS_PLIB_WARNING
#include<plib.h>

#define max 8192 //Max capacity in buffer

#pragma interrupt InterruptServiceRoutine IPL6AUTO vector 24 //Interrupts
#pragma interrupt Timer23ISR IPL5AUTO vector 12
#pragma interrupt Timer45ISR IPL5AUTO vector 20 


void InterruptServiceRoutine(void); //The ISR
void Timer23ISR(void); //Transmit
void Timer45ISR(void); //Receive

char Buffer[max]={'T'};

char * Head = Buffer; // points to where next item is to be placed if the buffer is not full
char * Tail = Buffer; //points to where next item can be removed if the buffer is not empty
char * Top = &Buffer[0]; //points to the beginning of the buffer in memory
char * End = &Buffer[max]; //points to the end of the buffer in memory
int num_items = 0; //number of items in the buffer
int DisableAtNextTx = 0;        //flag is activated once buffer is empty 
                                //and transmission can stop

void Insert(char);
char Remove();

int main()

{
    int counter=0;
    int i=0;
    
    SYSTEMConfig(80000000L,SYS_CFG_WAIT_STATES|SYS_CFG_PCACHE); 
        
    OpenTimer1(T1_OFF | T1_SOURCE_INT | T1_PS_1_1, 1200); //Debounce Button AKA CHANGE NOTIFICATION
    mT1SetIntPriority(5); //Sets the IPL in Hardware for CHANGE NOTIFICATION
    mT1SetIntSubPriority(1); //Sets the Sub Priority
   
    OpenTimer23(T23_OFF | T23_SOURCE_INT | T23_PS_1_256, 156250); //Transmit
    mT23SetIntPriority(5); //Sets the IPL in Hardware for Timer 2 and 3
    mT23SetIntSubPriority(2); //Sets the Sub Priority
    mT23IntEnable(1);
    
    OpenTimer45(T45_OFF | T45_SOURCE_INT | T45_PS_1_256, 156250); //Receive
    mT45SetIntPriority(5);
    mT45SetIntSubPriority(3);
    mT45IntEnable(1);
    
    U1MODEbits.RTSMD=0; //Setting Flow Control
    U1MODEbits.UEN=0b10; //U2TX, U2RX, U2CTS, and U2RTS pins are enabled and used
    
    //PORT
    TRISFbits.TRISF3=0;// Set as output
    LATFbits.LATF3=1; // Output high (idle)
    
   //Receive LED
    TRISDbits.TRISD0=0; //Configuring PORTB10 as an output TRISD
    LATDbits.LATD0=0; //Setting the LATB B10 PORTD
    
    
    //Transmit LED
    TRISDbits.TRISD1=0; //Configuring PORTB10 as an output TRISD
    LATDbits.LATD1=0; //Setting the LATB B10 PORTD
    
    
    //Overflow LED
    TRISDbits.TRISD2=0; //Configuring PORTB10 as an output TRISD
    LATDbits.LATD2=1; //Setting the LATB B10 PORTD
    
    //Button RD13 
    TRISCbits.TRISC2=1; //Setting up as input
    LATCbits.LATC2=1; //Setting up LATC RC1 as
    
    U1BRG=173; //That gives a baud rate of 114.9 K which gives the least error
    U1MODEbits.BRGH=1; //BRGH is 4 
    
    U1MODEbits.PDSEL=00; //8 bits, no parity
    U1MODEbits.STSEL=0; //1 stop bit
    
    IEC0bits.U1TXIE=1; //Setting for transmit interrupts
    IEC0bits.U1RXIE=1; //Setting for receive interrupts
    
    mU1SetIntPriority(6);
    mU1SetIntSubPriority(1);
    
    INTEnableSystemMultiVectoredInt();//Setting up the multi vectored mode
    
    U1STAbits.UTXISEL=0b00; //when the buffer is full
    U1STAbits.URXISEL=0b00; //When character is received
    
    U1MODEbits.ON=1; //Turning the UART on
    
    U1STAbits.URXEN=1; //Setting the receiver on 
    
    while(1)
    { //DEBOUNCING THE BUTTON RC2
        
        if((PORTCbits.RC2==0))
        {
            for(i=0; i < 3; i++)
            {
              TMR1=0; //Clearing the Timer
              T1CONbits.TON=1; //Start the Timer
              while(TMR1!=1200); //15 ms time delay
                if(PORTCbits.RC2==0)
                {   
                    counter++;
                    IFS0CLR=0x00000010;
                }
               T1CONbits.TON=0; //Turn off timer
            }
            if(counter==3)
            {
                LATDbits.LATD1=0; //Setting the LATB B10 PORTD
                U1STAbits.UTXEN=1; //Starting the UART transmission
                for(i=0; i < 2; i++)
                {
                    TMR1=0; //Clearing the Timer
                    T1CONbits.TON=1; //Start the Timer
                    while(TMR1!=1200);
                    T1CONbits.TON=0; //Start the Timer
                    
                }
                      
            }
            
            counter=0;   
            T1CONbits.TON=0; //Stop Timer 
            TMR1=0; //Clear Timer
            
        }
    }
    return 0;
}
   

void InterruptServiceRoutine(void)
{   
   
    
   /****************RECEIVE**************/
    if(IFS0bits.U1RXIF==1)
    {
       if(LATDbits.LATD0==0)
      {
           LATDbits.LATD0=1;
           T4CONbits.TON = 1;  //assert that timer4 is on
       }
        if (U1STAbits.URXDA==1 )
        {
           Insert(U1RXREG);
           IFS0CLR=0x08000000; //Clearing the receive interrupt flag 
        }
        
    }
    /**********TRANSMIT*********************/
    else if(IFS0bits.U1TXIF==1)
    {
        if(LATDbits.LATD1==0)
        {
           LATDbits.LATD1=1;
           T2CONbits.TON = 1;  //assert that timer2 is on
        }
        if(DisableAtNextTx)
        {
            U1STAbits.UTXEN = 0; //Stopping the UART transmission
            DisableAtNextTx = 0;
        }
        else if(U1STAbits.UTXBF!=1)
        {
            U1TXREG = Remove();
        }
       IFS0CLR=0x10000000; //Clearing the transmit interrupt flag
   }  
}

void Timer23ISR(void)
{
    T2CONbits.TON=0; //Turn off the timer
    LATDbits.LATD1=0; //Turn off the TX LED
    TMR2=0; //Clear the Timer 
    TMR3=0; //Clear the Timer
    IFS0CLR= 0x00001100; //Clear the T2 Interrupt Flag
}

void Timer45ISR()
{
    T4CONbits.TON=0; //Turn off the timer
    LATDbits.LATD0=0; //Turn off the RX LED
    TMR4=0; //Clear the Timer 
    TMR5=0; //Clear the Timer 
    IFS0CLR=0x00110000; //Clear the T2 Interrupt Flag
}

void Insert(char temp)
{
    
    if(num_items < max) //buffer not full
    {
        *Head=temp;
        num_items++;
        Head++;
        if(Head>End) 
        {
            Head=Top; //Make buffer circular
        }
    }
    else
    {
        PORTDbits.RD2=1; //Turn on Overflow LED
    }
}

char Remove()
{
    char read_item='\0';
    
    if(num_items > -1) //buffer not empty
    {
        read_item=*Tail;
        num_items--;
        Tail++;
        if(Tail > End)
        {
            Tail=Top; //Make buffer circular
        }    
    }
    else
    {
        DisableAtNextTx = 1;
    }
    PORTDbits.RD2=0; //Turn off Overflow LED
    return read_item;
}