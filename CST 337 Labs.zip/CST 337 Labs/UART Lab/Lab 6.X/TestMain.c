///*******LOST MY FIRST CODE, BUT LOOKS LIKE THIS*******/
//#pragma config POSCMOD=XT, FNOSC=PRIPLL, FPLLIDIV=DIV_2, FPLLMUL=MUL_20
//#pragma config FPLLODIV=DIV_1
//#pragma config FPBDIV=DIV_1, FWDTEN=OFF, CP=OFF, BWP=OFF
//#pragma config FSOSCEN=OFF, IESO=OFF
//
//#include <xc.h>
//#define _SUPPRESS_PLIB_WARNING
//#include<plib.h>
//
//#pragma interrupt InterruptServiceRoutine IPL6AUTO vector 24 
//
//void InterruptServiceRoutine(void); //The ISR
//char Buffer='\0';
//
//int main()
//{
//    SYSTEMConfig(80000000L,SYS_CFG_WAIT_STATES|SYS_CFG_PCACHE); 
//   
//    U1BRG=173; //That gives a baud rate of 114.9 K which gives the least error
//    U1MODEbits.BRGH=1; //BRGH is 4 
//    
//    U1MODEbits.PDSEL=00; //8 bits, no parity
//    U1MODEbits.STSEL=0; //1 stop bit
//    
//    IEC0bits.U1TXIE=1; //Setting for transmit interrupts
//    IEC0bits.U1RXIE=1; //Setting for receive interrupts
//    
//    mU1SetIntPriority(6);
//    mU1SetIntSubPriority(1);
//    
//    INTEnableSystemMultiVectoredInt();//Setting up the multi vectored mode
//    
//    U1STAbits.UTXISEL=0b10; //when the buffer is full
//    U1STAbits.URXISEL=0b00; //When character is received
//    
//    U1STAbits.URXEN=1; //Setting the receiver on 
//    U1MODEbits.ON=1; //Turning the UART on
//    U1STAbits.UTXEN=1;
//    
//    
//    return 0;
//}
//   
//
//void InterruptServiceRoutine(void)
//{   
//    while(U1STAbits.URXDA==1)
//    {
//         Buffer=U1RXREG;
//         IFS0bits.U1RXIF=0;  
//    }    
//    while(U1STAbits.UTXBF==0)
//    {
//        U1TXREG=Buffer;
//        IFS0bits.U1TXIF=0;
//    }
//}
//
