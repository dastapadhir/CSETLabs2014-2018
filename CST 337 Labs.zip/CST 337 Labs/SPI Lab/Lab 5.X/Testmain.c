//#pragma config POSCMOD=XT, FNOSC=PRIPLL, FPLLIDIV=DIV_2, FPLLMUL=MUL_20
//#pragma config FPLLODIV=DIV_1
//#pragma config FPBDIV=DIV_1, FWDTEN=OFF, CP=OFF, BWP=OFF
//#pragma config FSOSCEN=OFF, IESO=OFF
//#include <xc.h>
//#define _SUPPRESS_PLIB_WARNING
//#include<plib.h>
//
//
//
//void writeEnable();
//int ReadStatus();
//void WriteSequence(int address, int data);
//int ReadSequence(int address);
//
//int address=0x401;
//
//int main()
//
//{
//    
//    SYSTEMConfig(80000000L,SYS_CFG_WAIT_STATES|SYS_CFG_PCACHE);
//  int data =0;  
//    
//   LATBbits.LATB10=1; //Setting the LATB B10 PORTB
//   TRISBbits.TRISB10=0; //Configuring PORTB10 as an output TRISB
//   AD1PCFGbits.PCFG10 = 1; //Set RB10 for Digital
//    
//   SPI1CON = 0;
//   SPI1BRG= 8; //Setting the Baud Rate Generator 225ns
//   SPI1CON=0x8060; //Turning on the SPI module Master, CKP = 1, CKE=0, SMP=0, 8 bit
//   
//   while(ReadStatus()& 0x01==1);
//   
//
//  data=ReadSequence(address);
//  while(ReadStatus()& 0x01==1);
//  WriteSequence(address, 'J');
//  while(ReadStatus()& 0x01==1);
//  data = ReadSequence(address);
//
//    return 0;
//    
//}
//
//void writeEnable()
//{
//    int dummy; 
//    LATBbits.LATB10 = 0; //Asserting the Chip Select
//    SPI1BUF=0x06; //Setting the Write Enable Command
//    while(SPI1STATbits.SPIRBF!=1); //Waiting for the Receive Buffer
//    
//   dummy = SPI1BUF; //Reading idummy
//    LATBbits.LATB10 = 1; //Negating the Chip Select
//    
//}
//
//int ReadStatus()
//{
//    short dummy;
//  LATBbits.LATB10=0; //Asserting the Chip Select
//   SPI1BUF=0x05; //Writing Read Status
//   while(SPI1STATbits.SPITBE!=1); //Waiting for transfer buffer empty
//   SPI1BUF='A'; //writing odummy
//    while(SPI1STATbits.SPIRBF!=1); //Waiting for the Receive Buffer
//   dummy=SPI1BUF; //Reading idummy
//    while(SPI1STATbits.SPIRBF!=1); //Waiting for the Receive Buffer
//    LATBbits.LATB10=1; //Negating the Chip Select
//    return SPI1BUF;
//    
//}
//
//
//void WriteSequence(int address, int data)
//{
//   int dummy; 
//    
//   LATBbits.LATB10 = 0; //Asserting the Chip Select
//    SPI1BUF=0x06; //Setting the Write Enable Command
//   while(SPI1STATbits.SPIRBF!=1); //Waiting for the Receive Buffer
//    
//    dummy = SPI1BUF; //Reading idummy
//    LATBbits.LATB10 = 1; //Negating the Chip Select
//  asm("nop");
//   asm("nop");
//    LATBbits.LATB10=0; //Asserting the Chip Select
//    SPI1BUF=0x02; //Write Command
//    while(SPI1STATbits.SPITBE!=1); //Waiting for transfer buffer empty
//    SPI1BUF=address>>8; //MSA
//   while(SPI1STATbits.SPIRBF!=1); //Waiting for the Receive Buffer
//    dummy=SPI1BUF; //Reading dummyA
//    SPI1BUF=address ; //LSA
//   while(SPI1STATbits.SPIRBF!=1); //Waiting for the Receive Buffer
//   dummy=SPI1BUF; //Reading dummyB
//    SPI1BUF=data;
//   while(SPI1STATbits.SPIRBF!=1); //Waiting for the Receive Buffer
//   dummy=SPI1BUF; //Reading dummyC
//    while(SPI1STATbits.SPIRBF!=1); //Waiting for the Receive Buffer
//    dummy=SPI1BUF; //Reading dummy1
//    LATBbits.LATB10=1; //Asserting the Chip Select        
// }
//
//int ReadSequence(int address)
//{
//    int dummy;
//    LATBbits.LATB10=0; //Asserting the Chip Select
//    SPI1BUF=0x03; //Read Command
//    while(SPI1STATbits.SPITBE!=1); //Waiting for transfer buffer empty
//    SPI1BUF=address>>8; //MSA
//    while(SPI1STATbits.SPIRBF!=1); //Waiting for the Receive Buffer
//    dummy=SPI1BUF; //Reading dummyA
//    SPI1BUF=address ; //LSA
//    while(SPI1STATbits.SPIRBF!=1); //Waiting for the Receive Buffer
//    dummy=SPI1BUF; //Reading dummyB
//    SPI1BUF='Z';
//    while(SPI1STATbits.SPIRBF!=1); //Waiting for the Receive Buffer
//    dummy=SPI1BUF; //Reading dummyC
//    while(SPI1STATbits.SPIRBF!=1); //Waiting for the Receive Buffer
//    dummy=SPI1BUF; //Reading dummy1
//    LATBbits.LATB10=1; //Asserting the Chip Select
//    return dummy;
//}