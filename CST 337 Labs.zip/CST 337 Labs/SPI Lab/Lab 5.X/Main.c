#pragma config POSCMOD=XT, FNOSC=PRIPLL, FPLLIDIV=DIV_2, FPLLMUL=MUL_20
#pragma config FPLLODIV=DIV_1
#pragma config FPBDIV=DIV_1, FWDTEN=OFF, CP=OFF, BWP=OFF
#pragma config FSOSCEN=OFF, IESO=OFF
#include <xc.h>
#define _SUPPRESS_PLIB_WARNING
#include<plib.h>
#pragma interrupt InterruptServiceRoutine IPL6AUTO vector 23
void InterruptServiceRoutine(void); //The ISR


//void writeEnable();
//int ReadStatus();
//void WriteSequence(int address, int data);
//int ReadSequence(int address);

void ReadEEProm(int nbytes, unsigned int address, unsigned char readbuffer[]); 
void WriteEEProm(int nbytes, unsigned int address, unsigned char writebuffer[]);

int EEPromSysBusy=0;
int State=0;
int GlobalAddress;
int GlobalBytes;
char * GlobalBuffer;
int bytes=100;
char anything[100]="My name is Tapadhir das and I am a CSET Major";
int address=0x401;

char readbuffer[100];
char * writebuffer;
int Operation;

int main()

{
    int i=0;
    SYSTEMConfig(80000000L,SYS_CFG_WAIT_STATES|SYS_CFG_PCACHE);
    writebuffer=&anything; 
 
    LATBbits.LATB10=1; //Setting the LATB B10 PORTB
    TRISBbits.TRISB10=0; //Configuring PORTB10 as an output TRISB
    
    LATBbits.LATB2=1;
    TRISBbits.TRISB2=0; 
    
    AD1PCFGbits.PCFG10 = 1; //Set RB10 for Digital
    AD1PCFGbits.PCFG2=1; //Setting RB12 for Digital
    
    SPI1CON = 0;
    SPI1BRG= 8; //Setting the Baud Rate Generator 225ns
    SPI1CON=0x8060; //Turning on the SPI module Master, CKP = 1, CKE=0, SMP=0, 8 bit
   
    IEC0bits.SPI1RXIE=1; //Setting the Interrupt
    mSPI1SetIntPriority(6);
    INTEnableSystemMultiVectoredInt();//Setting up the multi vectored mode
   
    WriteEEProm(bytes,address,writebuffer);
    ReadEEProm(bytes,address,readbuffer);
  //  ReadEEProm(bytes,address+1,readbuffer);
  //  ReadEEProm(bytes,address+2,readbuffer);
   // ReadEEProm(bytes,address+3,readbuffer);
  //  ReadEEProm(bytes,address+4,readbuffer);

    
   while (EEPromSysBusy == 1);
   // State = State;

    
    //while(ReadStatus()& 0x01==1);
   

   // data=ReadSequence(address);
    //while(ReadStatus()& 0x01==1);
   // WriteSequence(address, 'J');
   // while(ReadStatus()& 0x01==1);
   // data = ReadSequence(address);
   
   
    //SPI1STAT
     
    return 0;
    
}

void InterruptServiceRoutine(void)
{
    int dummy;
    
    switch(State) 
    {
        case 0: //Start Check Status
            LATBbits.LATB10=0; //Asserting Chip Select
            SPI1BUF=0x05; //Sending Read Status
            while(SPI1STATbits.SPITBE!=1); //Waiting for transfer buffer empty
            SPI1BUF='A'; //writing odummy
            State=1; //Setting the State to 1
            break;
            
        case 1: //Check Mid Status
            
            dummy=SPI1BUF; //Reading idummy
            State=2; //Setting State to 2
            break;
            
        case 2: //end Check Status, start Read or Write Enable or repeat Check
           // ReadStatus();
            dummy=SPI1BUF; //Receiving the data
            LATBbits.LATB10=1; //Negating Chip Select
            asm volatile ("nop");
            asm volatile ("nop");
            LATBbits.LATB10=0; //Asserting Chip Select
            
            if(dummy & 0x01==1) //Checking for WIP
            {
                LATBbits.LATB10=0;
                SPI1BUF=0x05; //Sending the Read Status to 25LC256
                while(SPI1STATbits.SPITBE!=1); //Waiting for transfer buffer empty
                SPI1BUF='A'; //writing odummy
                State=1; //Setting the State to 1
            }
            
            else if(Operation==1)  //Write 
            {
              SPI1BUF=0x06; //Setting the Write Enable Command 
              State=3; //Setting to State 3
            }
            else //Operation ==0
            {
                SPI1BUF=0x03; //Read Command
                while(SPI1STATbits.SPITBE!=1); //Waiting for transfer buffer empty
                SPI1BUF=GlobalAddress>>8; //MSA
                State=8; //Setting State to 4
            }
            break;
         
            //WRITING SEQUENCE   
        case 3:// End Write Enable 
            dummy=SPI1BUF; //read idummy
            LATBbits.LATB10=1; //Negating Chip Select
            asm volatile ("nop");
            asm volatile ("nop");
            LATBbits.LATB10=0; //Asserting Chip Select
            SPI1BUF= 0x02; //Sending the Write Command
            while(SPI1STATbits.SPITBE!=1); //Waiting for transfer buffer empty
            SPI1BUF=GlobalAddress>>8; //MSA
            State=4; //Setting State to 5
            break;
            
        case 4:
            dummy=SPI1BUF; //Reading dummyA
            SPI1BUF=GlobalAddress ; //LSA
            State=5;
            break;
            
        case 5:
            dummy=SPI1BUF; //Reading dummyB
            if(GlobalBytes==0)
            {
                SPI1BUF=*GlobalBuffer;
                State=6;
            }
            else
            {
                SPI1BUF=*(GlobalBuffer++);
                GlobalBytes--;
            }
           // State=6;
            break;
        
        case 6:
            dummy=SPI1BUF; //Reading dummyC
            State=7;
            break;
            
        case 7:
            dummy = SPI1BUF; //Reading dummy1
            LATBbits.LATB10=1; //Negating the Chip Select 
            State=0;
            EEPromSysBusy=0;
            
            break;
            
         //READING SEQUENCE  
        case 8: //Read Sequence
            
            dummy=SPI1BUF; //Reading the dummyA
            SPI1BUF=GlobalAddress; // LSA
            State=9;
            break;
            
        case 9:
            dummy=SPI1BUF; //Reading dummyB
            SPI1BUF='J';
            State=10;
            break;
         
        case 10:
           dummy=SPI1BUF; //Reading dummyC
           State=11;
           break;
           
        case 11:
            if(GlobalBytes==0)
            {
                *GlobalBuffer=(char)SPI1BUF; 
            }
            else
            {
                *GlobalBuffer=(char)SPI1BUF;
                GlobalBytes--;
            }
            LATBbits.LATB10=1; //Asserting the Chip Select    
            State=0;
            EEPromSysBusy=0;
            break;
    }
    
    IFS0bits.SPI1RXIF=0; //Clearing SPI1RXIF
    mSPI1RXClearIntFlag();
}

void ReadEEProm(int nbytes, unsigned int address, unsigned char readbuffer[])
{
    while(EEPromSysBusy!=0);
    if(State!=0)
    {
        while(1);
    }
    EEPromSysBusy=1; //Setting EEPromSysBusy    
    GlobalBytes=nbytes; 
    GlobalAddress=address;
    GlobalBuffer=readbuffer;
    Operation=0;
    IFS0bits.SPI1RXIF=1; //Setting up SPI1RXIF
   
}

void WriteEEProm(int nbytes, unsigned int address, unsigned char writebuffer[])
{
    while(EEPromSysBusy!=0);
    if(State!=0)
    {
        while(1);
    }
    
   EEPromSysBusy=1; //Setting EEPromSysBusy
   GlobalBytes=nbytes; 
   GlobalAddress=address;
   GlobalBuffer=writebuffer;
   Operation=1;
   IFS0bits.SPI1RXIF=1; //Setting up SPI1RXIF
     
}

